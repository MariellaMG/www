<?php
if($_GET["q"]=="1"){
	header( 'Location: http://sdm-creative.com/tajin' ) ;
}
?>
<?php
include 'browser.php';
if($berry==1){
	header( 'Location: http://solocondesa.com/iphone_index.php' ) ;
}
?>
<?php //include("cache.start.php"); ?>
<?php 
include 'includes/includes.php';
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="language" content="es" />
<meta name="author" content="<?php echo $global_solo1;?>" />
<meta name="description" content="<?php echo $global_descripcion;?>" />
<meta name="keywords" content="Bares , Restaurantes , Restaurante , Antros , Cafeterias Heladerias, colonia condesa, solocondesa, coloniacondesa, directorios condesa " />
<!-- scripts lightbox 
<script type="text/javascript" src="javascript/prototype.js"></script>
<script type="text/javascript" src="javascript/scriptaculous.js?load=effects"></script>
<script type="text/javascript" src="javascript/lightwindow.js"></script>
<link rel="stylesheet" href="styles/lightwindow.css" type="text/css" media="screen" />
 -->
<title><?php echo $global_solo;?> | <?php echo $global_slogan;?></title>
<!--[if lt IE 7]>
<script defer type="text/javascript" src="js/pngfix.js"></script>
<link href="styles/ie.css" rel="stylesheet" type="text/css" />
<![endif]-->
<link href="styles/main.css" rel="stylesheet" type="text/css" />

<style type="text/css">
<!--
.textoPrincipal{
	 height:120px; 
	 background-color:#ffffff; 
	 width:750px; 
	 margin-left:70px; 
	 color:#000000; 
	 font-size:12px; 
	 font-family:Verdana, Geneva, sans-serif;
	 line-height:18px;
}
.textoInterno{
	margin:20px;
	margin-top:15px;
}
.textoPrincipal h1{
	background-color:#2A2A2A;
	width:320px;
	color:#FFF;
	padding:6px;
	padding-left:18px;
	margin-bottom:10px;
	font-size:20px;
}
.textoPrincipal h2{
	display:inline;
	background-color:#000000;
	color:#FFDE00;
	padding-left:4px;
	padding-right:4px;
	padding-top:1px;
	padding-bottom:1px;
}
.textoPrincipal h3{
	display:inline;
	background-color:#000000;
	color:#FFDE00;
	padding-left:4px;
	padding-right:4px;
	margin-left:2px;
	margin-right:2px;
	padding-top:2px;
	padding-bottom:2px;
}
.textoPrincipal h3 a{
	text-decoration:none;
	color:#FFDE00;
}
.textoPrincipal h3 a:hover{
	text-decoration:none;
	color:#CCC;
}
-->
</style>
<script>
if (navigator.userAgent.indexOf('iPhone') != -1) {
window.location = "./iphone_index.php"
}
if (navigator.userAgent.indexOf('Berry') != -1) {
window.location = "./iphone_index.php"
}
if (navigator.userAgent.indexOf('iPod') != -1) {
window.location = "./iphone_index.php"
}
if (navigator.userAgent.indexOf('Android') != -1) {
window.location = "./iphone_index.php";
}
if (navigator.userAgent.indexOf('iPad') != -1) {
//window.location = "./index2.php";
}
</script>
<script src="js/jquery.js" type="text/javascript"></script>
<script src="js/amor-placer-y-sexo.js" type="text/javascript"></script>
</head>
<body>
<div id="amor" style="width:199px; height:172px; position:absolute; z-index:11; margin-top:250px;">
<a href="http://amorplacerysexo.com/?s=solocondesa" target="_blank"><img src="amor-placer-y-sexo-com/amor-placer-y-sexo.png" width="199" height="172" /></a>
</div>
<div id="amord" style="width:199px; height:172px; position:absolute; z-index:11; margin-top:730px;">
<a href="http://amorplacerysexo.com/?s=solocondesa" target="_blank"><img src="amor-placer-y-sexo-com/amor-placer-y-sexo-d.png" width="199" height="172" /></a>
</div>
<a rel="author" href="http://sebastianaguilar.me/" style="display:none;">Sebastián Aguilar</a>
<!-- Start header -->
<?php include ("common_files/header.php"); ?>
<div class="clearer"></div>
<!-- End header -->

<div class="mainpageholder">
	<div class="mainleftbk" style="height:580px;">
		<div class="mainleft">
<?php include ("common_files/izq_menu.php"); ?>
			<div id="botpage"></div>
		</div>
	</div>
    
	<div class="mainright">
		<div id="toppicture" style="height:380px;">
			
            
            <div style="width:750px; height:375px; margin:0 0 0 69px;">
<?php //include ("common_files/banner.php"); ?>
<a href="http://picpet.mx" target="_blank">
<img src="bannerspicpet/Banner1.jpg" width="700" height="375" border="0" />
</a>
</div>
		</div>
        
     
     
     <div class="textoPrincipal">
     
     <div class="textoInterno">
     
     <h1>Toda la colonia Condesa está aquí.</h1>

<h2>Solo Condesa</h2> es la única comunidad virtual que te acercará hasta el último rincón de tu zona preferida de la Ciudad de México.
<br />
Encuentra los mejores <h3><a href="directorio/restaurante">restaurantes</a></h3>
, <h3><a href="directorio/antro">antros</a></h3>, <h3><a href="directorio/bar">bares</a></h3>, <h3><a href="directorio/cafeterias-y-helados">cafeter&iacute;as</a></h3> y todo tipo de establecimientos para disfrutar del ambiente en la <h2>colonia Condesa</h2>.
<br />
Entérate antes que nadie de eventos y promociones especiales que Solo Condesa trae para ti. <br />
Conoce tambi&eacute;n la historia de la <h3><a href="post/historia-de-la-colonia-condesa">Colonia Condesa</a></h3>

</div>
     
     </div>   
     
        
	</div>
	<br clear="all">
</div>
</div>
<!-- center -->
<div class="fullcentre">
	<div id="mainbodyside">
		<div class="homeboxsurround">
			<table>
				<tr>
					<td>
						<div class="homebox">
							<div class="homeboxcontent">
								<?php echo $destacados[5]["destacado"];?>
								<div class="homebotpic">
									<a href="./visita/<?php echo $des1->permalink;?>">
										<img src="./archivos/<?php echo $des1->thumb;?>" width="180" height="120" />									</a>							  </div>
							  <!-- homepic --> 
							
						  <?php echo $des1->descdestacado;?></div>
							<!-- homecontent -->
							<div class="infobut">
								<a class="infobutroll" href="./visita/<?php echo $des1->permalink;?>">
									Alto Tango
								</a>
							</div>
						</div>
						<div class="homeboxbot1"><!-- homebot --></div>
					</td>
					<td>
						<div class="homebox">
						  <div class="homeboxcontent"><?php echo $destacados[1]["destacado"];?>
						    <div class="homebotpic">
									<a href="./visita/<?php echo $des2->permalink;?>">
										<img src="./archivos/<?php echo $des2->thumb;?>" width="180" height="120" />
									</a>
					      </div>
							  <!-- homepic -->
							 <?php echo $des2->descdestacado;?></div>
							<!-- homecontent -->
							<div class="infobut">
								<a class="infobutroll" href="./visita/<?php echo $des2->permalink;?>"></a>
							</div>
						</div>
						<div class="homeboxbot2"><!-- homebot --></div>
					</td>
					<td><div class="homebox">
					  <div class="homeboxcontent"><?php echo $destacados[2]["destacado"];?>
					    <div class="homebotpic"> <a href="./visita/<?php echo $des3->permalink;?>"> <img src="./archivos/<?php echo $des3->thumb;?>" alt="-" width="180" height="120" /> </a> </div>
					    <?php echo $des3->descdestacado;?>
					    <h1>&nbsp;</h1>
				      </div>
					  <!-- homecontent -->
					  <div class="infobut"> <a href="./visita/<?php echo $des3->permalink;?>" class="infobutroll"> </a> </div>
					  </div>					  <div class="homeboxbot3"><!-- homebot --></div>
					</td>
					<td>
						<div class="homebox">
		    <div class="homeboxcontent">
								<?php echo $destacados[3]["destacado"];?>
								<div class="homebotpic">
									<a href="./visita/<?php echo $des4->permalink;?>">
										<img src="./archivos/<?php echo $des4->thumb;?>" width="180" height="120" />
									</a>
				    </div>
						  <?php echo $des4->descdestacado;?></div>
							<!-- homecontent -->
							<div class="infobut">
								<a href="./visita/<?php echo $des4->permalink;?>" class="infobutroll">
									
								</a>
							</div>
						</div>
						<div class="homeboxbot4"><!-- homebot --></div>
					</td>
					<td><div class="homebox">
					  <div class="homeboxcontent"> <?php echo $destacados[4]["destacado"];?>
					    <div class="homebotpic"> <a href="./post/<?php echo $des5->permalink;?>"> <img src="./archivos/<?php echo $des5->thumb;?>" alt="-" width="180" height="120" /> </a> </div>
					    <!-- homepic -->
					    <?php echo $des5->descdestacado;?><a href="" ></a></div>
					  <!-- homecontent -->
					  <div class="infobut"> <a href="./post/<?php echo $des5->permalink;?>" class="infobutroll"> mas </a> </div>
					  </div>					  <div class="homeboxbot5"><!-- homebot --></div>
					</td>
				</tr>
			</table>
		</div>
		<div class="clearer"></div>
	</div>
	<div class="clearer"></div>
</div>
<!-- fullcentre -->
<div class="clearer"></div>




</div>
<!-- closes main -->

<!-- Start footer -->
<?php
include ("common_files/footer.php");
?>
<!-- End footer -->



</div>
<!-- this closes contents -->



<script>
// execute your scripts when DOM is ready. this is a good habit
$(function() {		
		
	// initialize scrollable 
	$("div.scrollable").scrollable({
		size: 1,
		items: '#thumbs',  
		hoverClass: 'hover',interval: 4000, 
         
        // when last item is encountered go back to first item 
        loop: true,  
         
        // make animation a little slower than the default 
        speed: 600
	});	
	
});
<?php
include ("common_files/analytics.php");
?>
<?php include("cache.end.php"); ?>